#!/bin/bash

# Run this ONLY on the master node
kubeadm init --apiserver-advertise-address=10.0.1.10 --pod-network-cidr=192.168.0.0/16

# Set up local kubeconfig
mkdir -p $HOME/.kube
cp /etc/kubernetes/admin.conf $HOME/.kube/config
chown $(id -u):$(id -g) $HOME/.kube/config